# Conexión con el bot de Telegram @DAURYIOSBOT (keys)

La app valida las keys creadas por @DAURYIOSBOT contra:
https://daury-ios-keys.lovable.app

- POST /api/public/activate     -> { key, device_id }
- POST /api/public/patches      -> { key, device_id }
- POST /api/public/maintenance  -> { key, device_id, enabled? }

IMPORTANTE: si modificas o mejoras este ZIP, NO cambies `PantherAPIBaseURL` en
ThreeOneOSFive/Info.plist y la app seguirá conectada al bot.

Comandos del bot: /crear 7d [cantidad], /crearadmin 30d, /info KEY, /extender KEY 3d,
/dispositivos KEY 2, /ban KEY, /desban KEY, /reset KEY, /borrar KEY, /keys, /mantenimiento on|off.
La duración empieza a contar cuando la key se activa por primera vez en un iPhone.
